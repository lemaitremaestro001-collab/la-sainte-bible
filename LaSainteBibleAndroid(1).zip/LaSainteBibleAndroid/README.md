# La Sainte Bible — projet Android de démarrage

Application Android légère basée sur une WebView locale. Le contenu d'interface est embarqué dans `app/src/main/assets/index.html` et fonctionne sans réseau.

## Compilation
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- Android SDK 35

Depuis un environnement Android/Gradle : `gradle assembleDebug`.

Ce projet est un squelette de démarrage : il ne contient pas encore les corpus bibliques complets ni les fichiers audio. Ajouter uniquement des éditions dont les droits d'utilisation sont vérifiés.
